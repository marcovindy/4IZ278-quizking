<nav class="sidebar">
  <div class="flex-shrink-0 h-100">

    <ul class="list-unstyled ps-0">
    <li class="mb-1">
        <a href="index.php" class="link-dark rounded hyper-item">Přehled kvízů
          <span></span><span></span>
        </a>
      </li>
      <li class="mb-1">
        <a href="custom-quiz.php" class="link-dark rounded hyper-item">Vlastní kvízy
          <span></span><span></span>
        </a>
      </li>
      <li class="mb-1">
        <a href="shop.php" class="link-dark rounded hyper-item">Obchod
          <span></span><span></span>
        </a>
      </li>
      <li class=" mb-1">
        <button class="w-100 text-left  btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target="#dashboard-collapse" aria-expanded="false">
          Další možnosti
        </button>
        <div class="collapse" id="dashboard-collapse">
          <ul class="btn-toggle-nav list-unstyled fw-normal pb-1">
            <li><a href="report.php" class="link-dark rounded hyper-item">Nahlásit problém
                <span></span><span></span>
              </a></li>     <li><a href="kontakt.php" class="link-dark rounded hyper-item">Kontakt
                <span></span><span></span>
              </a></li>
            
          </ul>
        </div>
      </li>
      <li class="border-top my-3"></li>

    </ul>
  </div>
</nav>